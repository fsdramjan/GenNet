# AppTrack

Flutter Android local, per-app network usage monitor.

## Architecture

```
Flutter UI (home_page.dart)
   -> MonitorService (MethodChannel + EventChannel: "apptrack/monitor")
   -> MainActivity.kt
   -> Android NetworkStatsManager (official OS API, per-UID rx/tx counters)
```

There is no VpnService, no TUN interface, no local socket server, and
no third-party proxy/VPN core. AppTrack reads existing OS-maintained
network counters for the UIDs of apps the user explicitly selects.
Nothing is transmitted off the device -- there is no server, no
`INTERNET` permission, and no export destination other than local
files the user chooses to keep or share themselves.

## Why not VpnService/TUN?

An earlier iteration of this project routed a target app's traffic
through a VPN/TUN core. That design requires forwarding every packet
yourself (or via a mature engine) or the monitored app loses internet
access, and it enables connection-level interception of another app's
traffic. `NetworkStatsManager` gives accurate aggregate upload/download
totals per app with none of that risk or complexity, and it's the same
API Android's own Settings > Data usage screen uses.

## Setup

1. Install Flutter 3.19+.
2. `flutter clean && flutter pub get`
3. `flutter run`

On first launch, granting **Usage Access** (Settings, opened from
within the app) is required -- this is a special Android app-op, not
a manifest permission, so it can't be requested any other way.

## Using the app

1. Tap **Select apps** and choose one or more installed apps.
2. Press **START**. Live upload/download/total bytes appear per app,
   plus a running session duration.
3. Press **STOP** to end the session.
4. Export the current statistics as CSV or TXT from the toolbar menu.
   Files are written to the app's local `exports` directory.

## Known limitations

- Statistics update on a 2-second poll while the app is in the
  foreground; there is no background/foreground service keeping the
  session alive when AppTrack itself is backgrounded or the device
  sleeps (Doze). A foreground `Service` with a persistent notification
  would be the natural next step if background monitoring is needed.
- Mobile-network (cellular) byte counts may read as zero on some
  OEM builds because `querySummaryForUid` for `TYPE_MOBILE` can
  require additional phone-state access; failures are caught and
  logged rather than crashing the session. Wi-Fi counts are
  unaffected.
- The app selector lists launchable (user-facing) apps, not every
  installed package/service, consistent with Android 11+ package
  visibility norms.
- Build/analyze/run could not be executed in the environment that
  produced this code (no Android SDK, no network access to
  `pub.dev`/Google's Maven). Run the commands in "Setup" locally to
  verify.
